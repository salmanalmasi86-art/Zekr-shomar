package ir.zekr.shomar

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var count = 0
    private lateinit var root: LinearLayout
    private lateinit var stageName: TextView
    private lateinit var stageCount: TextView
    private lateinit var total: TextView
    private lateinit var progress: TextView
    private val green = Color.rgb(16, 45, 37)
    private val gold = Color.rgb(230, 199, 122)
    private val names = arrayOf("سبحان الله", "الحمد الله", "الله اکبر")
    private val limits = intArrayOf(33, 33, 34)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        count = getPreferences(Context.MODE_PRIVATE).getInt("count", 0)
        buildUi()
        updateUi()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(12, 10, 12, 10)
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(22, 20, 22, 20)
            setBackgroundColor(green)
        }
        root.addView(label("اهدایی از طرف", 18f, gold, true))
        root.addView(label("مرحوم مغفور", 22f, gold, true))
        root.addView(label("کربلایی مهری ایران‌پرست", 24f, gold, true))
        root.addView(label("به یاد و نیت خیر ایشان", 14f, Color.LTGRAY))
        root.addView(label("✦  ✦  ✦", 18f, gold))
        stageName = label("", 32f, gold, true)
        root.addView(stageName)
        stageCount = label("", 27f, Color.WHITE, true)
        root.addView(stageCount)
        progress = label("", 16f, Color.LTGRAY)
        root.addView(progress)
        total = label("", 22f, gold, true)
        root.addView(total)

        val touchArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(27, 73, 56))
            setPadding(20, 35, 20, 35)
            isClickable = true
            addView(label("برای شمارش، هر جای صفحه را لمس کنید", 19f, Color.WHITE, true))
            addView(label("ذکر با هر لمس یک عدد افزایش می‌یابد", 14f, Color.LTGRAY))
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_DOWN) {
                    if (count < 100) {
                        count++
                        getPreferences(Context.MODE_PRIVATE).edit().putInt("count", count).apply()
                        vibrate()
                        updateUi()
                    }
                    true
                } else true
            }
        }
        root.addView(touchArea, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val reset = Button(this).apply {
            text = "از اول"
            textSize = 18f
            setOnClickListener {
                count = 0
                getPreferences(Context.MODE_PRIVATE).edit().putInt("count", 0).apply()
                updateUi()
            }
        }
        root.addView(reset, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        setContentView(root)
    }

    private fun vibrate() {
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= 26)
            vibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
        else @Suppress("DEPRECATION") vibrator.vibrate(25)
    }

    private fun updateUi() {
        val stage = when {
            count < 33 -> 0
            count < 66 -> 1
            else -> 2
        }
        val within = when (stage) {
            0 -> count
            1 -> count - 33
            else -> count - 66
        }
        stageName.text = if (count == 100) "ذکرها کامل شد" else names[stage]
        stageCount.text = if (count == 100) "۱۰۰ / ۱۰۰" else "${toFa(within)} / ${toFa(limits[stage])}"
        progress.text = "مرحله ${toFa(stage + 1)} از ۳"
        total.text = "مجموع ذکرها: ${toFa(count)} / ۱۰۰"
    }

    private fun toFa(n: Int): String = n.toString().map {
        if (it in '0'..'9') ('۰'.code + (it - '0')).toChar() else it
    }.joinToString("")
}
